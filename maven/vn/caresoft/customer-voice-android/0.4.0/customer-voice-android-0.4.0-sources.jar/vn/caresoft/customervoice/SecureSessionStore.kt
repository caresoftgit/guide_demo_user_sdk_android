package vn.caresoft.customervoice

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal class SecureSessionStore(context: Context, private val scope: String) {
    // noBackup prevents credential/installation cloning onto another installation.
    private val file=java.io.File(context.noBackupFilesDir,"customer-voice-session")
    private val installation=java.io.File(context.noBackupFilesDir,"customer-voice-installation")
    val installationId: String = synchronized(SecureSessionStore::class.java) {
        if(installation.exists()) UUID.fromString(installation.readText()).toString()
        else UUID.randomUUID().toString().also { installation.writeText(it) }
    }
    private fun key(): SecretKey {
        val store=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias="customer-voice.session.v1"
        return (store.getKey(alias,null) as? SecretKey) ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            generateKey()
        }
    }
    @Synchronized fun save(credentials: Credentials) {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,key()); updateAAD(scope.toByteArray()) }
        val encrypted=cipher.doFinal(credentials.json().toString().toByteArray())
        val data=JSONObject().put("iv",Base64.encodeToString(cipher.iv,Base64.NO_WRAP)).put("data",Base64.encodeToString(encrypted,Base64.NO_WRAP)).toString()
        android.util.AtomicFile(file).apply { val out=startWrite(); try { out.write(data.toByteArray()); finishWrite(out) } catch(e: Exception) { failWrite(out); throw e } }
    }
    @Synchronized fun load(): Credentials? = if(!file.exists()) null else try {
        val j=JSONObject(file.readText())
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(j.getString("iv"),Base64.NO_WRAP))); updateAAD(scope.toByteArray()) }
        Credentials.parse(JSONObject(String(cipher.doFinal(Base64.decode(j.getString("data"),Base64.NO_WRAP)))))
    } catch(e: Exception) { clear(); null }
    @Synchronized fun clear() { file.delete() }
}
