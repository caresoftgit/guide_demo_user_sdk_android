package vn.caresoft.customervoice

import android.app.PendingIntent
import java.net.URI
import java.time.Instant

/** Configure at Application startup. Never place tenant credentials in this object. */
data class VoiceConfig(val backendUrl: String, val accountId: String, val appId: String,
    val notificationTitle: String = "Customer Voice", val incomingIntent: PendingIntent? = null,
    val allowDebugLoopback: Boolean = false) {
    init {
        require(accountId.matches(Regex("[1-9][0-9]{0,9}")) && accountId.toLong() <= 4294967295L) { "Invalid account_id" }
        require(appId.isNotBlank()) { "App ID required" }
    }
}
data class SessionInfo(val userId: String, val sessionId: String, val expiresAt: Instant)
sealed interface SessionState {
    data object LoggedOut : SessionState
    data class Authenticated(val session: SessionInfo) : SessionState
    data class LoginRequired(val reason: String) : SessionState
}
data class AudioRoute(val id: String, val name: String, val type: Int, val selected: Boolean = false)
enum class CallConnectionState { CONNECTING, CONNECTED, RECONNECTING }
data class CallAudioState(val muted: Boolean = false, val routes: List<AudioRoute> = emptyList())
data class VoiceEvent(val type: String, val callId: String? = null, val code: String? = null)
class VoiceException(val code: String, val status: Int = 0) : Exception(code)
data class CallSnapshot(val callId: String, val direction: String, val state: String, val version: Long,
    val businessNumber: String? = null,
    val ringingExpiresAt: Instant? = null, val mediaExpiresAt: Instant? = null,
    val endedAt: Instant? = null, val endReason: String? = null,
    val deviceStatus: String? = null, val isOwner: Boolean = false) {
    val terminal: Boolean get() = state.uppercase() in setOf("ENDED", "FAILED", "CANCELLED", "REJECTED")
    val lost: Boolean get() = deviceStatus?.lowercase() in setOf("rejected", "answered_elsewhere", "loser", "revoked")
    fun canRing(now: Instant): Boolean = direction.uppercase() == "INBOUND" &&
        state.uppercase() == "RINGING" && !lost && ringingExpiresAt?.isAfter(now) == true
}
internal class CallLedger {
    private val entries = linkedMapOf<String, CallSnapshot>()
    @Synchronized fun apply(next: CallSnapshot) {
        val old = entries[next.callId]
        if (old != null && (old.terminal || next.version <= old.version)) return
        entries[next.callId] = next
    }
    @Synchronized fun values(): List<CallSnapshot> = entries.values.toList()
    @Synchronized fun visible(locallyStopped: Set<String>): List<CallSnapshot> = entries.values.filter {
        it.callId !in locallyStopped || it.terminal || it.lost
    }
    @Synchronized fun clear() = entries.clear()
}
internal object PushGate {
    fun accepts(data: Map<String,String>, session: String, app: String, now: Instant): Boolean =
        data["type"] in setOf("voice.incoming", "voice.ended") && data["session_id"] == session &&
        data["app_id"] == app && !data["call_id"].isNullOrBlank() &&
        runCatching { Instant.parse(data["expires_at"]).isAfter(now) }.getOrDefault(false)
}
internal fun validateBackend(url: String, debugLoopback: Boolean) {
    val uri = URI(url)
    require(uri.host != null && uri.userInfo == null && uri.query == null && uri.fragment == null) { "Invalid backend URL" }
    require(uri.scheme == "https" || (debugLoopback && uri.scheme == "http" &&
        uri.host in setOf("localhost", "127.0.0.1", "10.0.2.2", "::1"))) { "HTTPS required" }
}
internal fun dtmfCode(digit: Char): Int = when(digit) {
    in '0'..'9' -> digit - '0'
    '*' -> 10
    '#' -> 11
    else -> throw IllegalArgumentException("DTMF must be 0-9, * or #")
}
