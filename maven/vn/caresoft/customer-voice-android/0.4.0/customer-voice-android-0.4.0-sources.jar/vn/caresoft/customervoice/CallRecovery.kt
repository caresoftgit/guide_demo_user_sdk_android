package vn.caresoft.customervoice

import kotlinx.coroutines.*

/** One deadline per continuous outage. All calls are confined to the SDK main scope. */
internal class CallRecovery(private val scope: CoroutineScope,
    private val changed: (CallConnectionState)->Unit, private val timedOut: ()->Unit) {
    var state=CallConnectionState.CONNECTING; private set
    var generation=0L; private set
    var hasConnected=false; private set
    private var closed=false
    private var deadline: Job?=null
    fun begin(): Long {
        if(closed) return generation
        generation++
        if(state!=CallConnectionState.RECONNECTING) { state=CallConnectionState.RECONNECTING;changed(state) }
        if(deadline==null) deadline=scope.launch(start=CoroutineStart.UNDISPATCHED) {
            delay(30000)
            if(!closed) { closed=true;generation++;timedOut() }
        }
        return generation
    }
    fun current(ticket: Long)=!closed && generation==ticket
    fun connected(ticket: Long): Boolean {
        if(!current(ticket)) return false
        hasConnected=true;deadline?.cancel();deadline=null
        if(state!=CallConnectionState.CONNECTED) { state=CallConnectionState.CONNECTED;changed(state) }
        return true
    }
    fun stop() { closed=true;generation++;deadline?.cancel();deadline=null }
}

internal class NetworkPath<T>(private var current: T?) {
    fun available(next: T): Boolean { if(current==next) return false;current=next;return true }
    fun lost(old: T): Boolean { if(current!=old) return false;current=null;return true }
}
