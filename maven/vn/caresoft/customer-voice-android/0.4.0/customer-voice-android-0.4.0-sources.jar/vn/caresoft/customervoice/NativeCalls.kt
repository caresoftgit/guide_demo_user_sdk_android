package vn.caresoft.customervoice

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.telecom.DisconnectCause
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import androidx.core.telecom.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap

internal class NativeCalls(private val context: Context, private val config: VoiceConfig,
    private val scope: CoroutineScope, private val answer: suspend (String,Boolean)->Unit,
    private val disconnect: suspend (String)->Unit, private val haltMedia: (String)->Unit, private val muted: suspend (String,Boolean)->Unit,
    private val failed: (String,Exception)->Unit, private val audioChanged: (String,List<AudioRoute>)->Unit = {_,_->}, private val isCurrent: (String)->Boolean = {true}, private val now: ()->java.time.Instant = java.time.Instant::now) {
    private fun checkCurrent(id: String) { if(!isCurrent(id)) throw VoiceException("SESSION_CHANGED") }
    private val manager=CallsManager(context).apply { registerAppWithTelecom(CallsManager.CAPABILITY_BASELINE) }
    private val controls=ConcurrentHashMap<String,CompletableDeferred<CallControlScope>>()
    private val endpoints=ConcurrentHashMap<String,List<CallEndpointCompat>>()
    private val observedEndpoints=ConcurrentHashMap<String,MutableStateFlow<String?>>()
    private val jobs=ConcurrentHashMap<String,Job>()
    private val notices=context.getSystemService(NotificationManager::class.java)
    init { notices.createNotificationChannel(NotificationChannel(CHANNEL,config.notificationTitle,NotificationManager.IMPORTANCE_HIGH)) }
    suspend fun add(call: CallSnapshot): CallControlScope {
        checkCurrent(call.callId)
        val ready=controls.computeIfAbsent(call.callId) { id ->
            val deferred=CompletableDeferred<CallControlScope>()
            jobs[id]=scope.launch {
                try {
                    manager.addCall(CallAttributesCompat(call.businessNumber ?: config.notificationTitle,Uri.parse("sip:${Uri.encode(id)}"),
                        if(call.direction=="INBOUND") CallAttributesCompat.DIRECTION_INCOMING else CallAttributesCompat.DIRECTION_OUTGOING,
                        callCapabilities=0),
                        onAnswer={ answer(id,true) }, onDisconnect={ haltMedia(id); scope.launch { disconnect(id) }; Unit },
                        onSetActive={}, onSetInactive={ haltMedia(id); scope.launch { disconnect(id) }; Unit }) {
                        deferred.complete(this)
                        val observed=observedEndpoints.computeIfAbsent(id) { MutableStateFlow(null) }
                        launch { availableEndpoints.collect { if(isCurrent(id)) { endpoints[id]=it; audioChanged(id,routes(id)) } } }
                        launch { currentCallEndpoint.collect { if(isCurrent(id)) { observed.value=it.identifier.toString(); audioChanged(id,routes(id)) } } }
                        launch { isMuted.collect { if(isCurrent(id)) muted(id,it) } }
                    }
                } catch(e: CancellationException) { throw e }
                catch(e: Exception) { deferred.completeExceptionally(e); failed(id,e) }
                finally { controls.remove(id); endpoints.remove(id); observedEndpoints.remove(id); notices.cancel(id.hashCode()) }
            }
            deferred
        }
        // Post immediately: Telecom requires a call notification within five seconds.
        show(call)
        return withTimeout(5000) { ready.await() }
    }
    fun show(call: CallSnapshot) {
        checkCurrent(call.callId)
        val person=Person.Builder().setName(call.businessNumber ?: config.notificationTitle).setImportant(true).build()
        val reject=action(call.callId,"reject"); val hangup=action(call.callId,"hangup")
        val incoming=call.canRing(now())
        val style=if(incoming) NotificationCompat.CallStyle.forIncomingCall(person,reject,action(call.callId,"answer"))
            else NotificationCompat.CallStyle.forOngoingCall(person,hangup)
        val generic=Person.Builder().setName(config.notificationTitle).setImportant(true).build()
        val publicStyle=if(incoming) NotificationCompat.CallStyle.forIncomingCall(generic,reject,action(call.callId,"answer"))
            else NotificationCompat.CallStyle.forOngoingCall(generic,hangup)
        val publicNotice=NotificationCompat.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(config.notificationTitle).setContentText(if(incoming) "Cuộc gọi đến" else "Cuộc gọi đang diễn ra")
            .setStyle(publicStyle).setCategory(NotificationCompat.CATEGORY_CALL).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(config.incomingIntent).setOngoing(true).build()
        val builder=NotificationCompat.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(config.notificationTitle).setContentText(if(incoming) "Cuộc gọi đến" else "Cuộc gọi đang diễn ra")
            .setStyle(style).setOngoing(true).setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL).setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicNotice).setContentIntent(config.incomingIntent).setOnlyAlertOnce(true)
        // Only a fresh incoming ring may wake the supplied screen; Android enforces special access.
        if(incoming && config.incomingIntent!=null) builder.setFullScreenIntent(config.incomingIntent,true)
        val notification=builder.build()
        // CallStyle must be posted by startForeground on Android 14+, not before the service exists.
        VoiceCallService.notification=notification
        ContextCompat.startForegroundService(context,Intent(context,VoiceCallService::class.java).putExtra("call_id",call.callId))
    }
    private fun action(id: String, action: String): PendingIntent = PendingIntent.getBroadcast(context,(id+action).hashCode(),
        Intent(context,VoiceActionReceiver::class.java).setAction(action).setData(Uri.parse("customervoice://call/${Uri.encode(id)}/$action")).putExtra("call_id",id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    suspend fun activate(id: String, incoming: Boolean, fromTelecom: Boolean) {
        checkCurrent(id)
        val control=withTimeout(5000) { controls[id]?.await() ?: throw VoiceException("NATIVE_CALL_MISSING") }
        checkCurrent(id)
        if(!fromTelecom) {
            val result=if(incoming) control.answer(CallAttributesCompat.CALL_TYPE_AUDIO_CALL) else control.setActive()
            if(result !is CallControlResult.Success) throw VoiceException("TELECOM_ACTIVATION_DENIED")
        }
        checkCurrent(id)
        VoiceCallService.microphones.activate(id)
        context.startService(Intent(context,VoiceCallService::class.java).setAction("microphone").putExtra("call_id",id))
    }
    fun routes(id: String) = selectedRoutes(endpoints[id].orEmpty().map { AudioRoute(it.identifier.toString(),it.name.toString(),it.type) },observedEndpoints[id]?.value)
    suspend fun route(id: String, route: AudioRoute) {
        checkCurrent(id)
        val endpoint=endpoints[id]?.firstOrNull { it.identifier.toString()==route.id } ?: throw VoiceException("ROUTE_UNAVAILABLE")
        try { withTimeout(5000) {
            val control=controls[id]?.await() ?: throw VoiceException("NATIVE_CALL_MISSING"); checkCurrent(id)
            if(control.requestEndpointChange(endpoint) !is CallControlResult.Success) throw VoiceException("ROUTE_UNAVAILABLE")
            val observed=observedEndpoints[id] ?: throw VoiceException("ROUTE_UNAVAILABLE")
            observed.first { it==endpoint.identifier.toString() }; checkCurrent(id)
        } } catch(e: TimeoutCancellationException) { throw VoiceException("ROUTE_CHANGE_TIMEOUT") }
    }
    fun mediaEnded(id: String) {
        VoiceCallService.microphones.end(id)
    }
    suspend fun remove(id: String) {
        mediaEnded(id)
        runCatching { withTimeout(1500) { controls.remove(id)?.await()?.disconnect(DisconnectCause(DisconnectCause.LOCAL)) } }
        jobs.remove(id)?.cancel(); endpoints.remove(id); observedEndpoints.remove(id); notices.cancel(id.hashCode())
        if(controls.isEmpty()) context.stopService(Intent(context,VoiceCallService::class.java))
    }
    companion object { const val CHANNEL="customer_voice_calls" }
}

/** No Firebase service: the host retains ownership of its one messaging service. */
class VoiceActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending=goAsync()
        CustomerVoice.runAction(intent.action.orEmpty(),intent.getStringExtra("call_id").orEmpty()) { pending.finish() }
    }
}
class VoiceCallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n=notification ?: run { stopSelf(); return START_NOT_STICKY }
        var type=if(Build.VERSION.SDK_INT>=29) ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL else 0
        if(microphones.needed() && Build.VERSION.SDK_INT>=30 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)
            type=type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        try { if(Build.VERSION.SDK_INT>=29) startForeground(7301,n,type) else startForeground(7301,n) }
        catch(e: Exception) { CustomerVoice.nativeServiceFailed(intent?.getStringExtra("call_id"),e); stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() { microphones.clear(); notification=null; super.onDestroy() }
    companion object {
        @Volatile internal var notification: Notification? = null
        internal val microphones=ForegroundMicrophones()
    }
}
