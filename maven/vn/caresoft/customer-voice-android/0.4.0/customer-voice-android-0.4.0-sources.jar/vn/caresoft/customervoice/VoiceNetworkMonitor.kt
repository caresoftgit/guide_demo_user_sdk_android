package vn.caresoft.customervoice

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import kotlinx.coroutines.*

/** Observe the default route, including make-before-break Wi-Fi/mobile handoff. */
internal class VoiceNetworkMonitor(context: Context, private val scope: CoroutineScope, private val changed: ()->Unit) {
    private val manager=context.getSystemService(ConnectivityManager::class.java)
    private val path=NetworkPath(manager.activeNetwork)
    private var active=true
    private val callback=object: ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { scope.launch { if(active && path.available(network)) changed() } }
        override fun onLost(network: Network) { scope.launch { if(active && path.lost(network)) changed() } }
    }
    init { manager.registerDefaultNetworkCallback(callback) }
    fun close() { active=false;manager.unregisterNetworkCallback(callback) }
}
