package vn.caresoft.customervoice

import java.time.Instant
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal class SessionFence {
    private val version=AtomicLong()
    fun capture(): Long = version.get()
    @Synchronized fun advance(): Long = version.incrementAndGet()
    fun current(ticket: Long): Boolean = version.get()==ticket
    fun check(ticket: Long) { if(!current(ticket)) throw VoiceException("SESSION_CHANGED") }
    @Synchronized fun commit(ticket: Long, action: ()->Unit) { if(current(ticket)) action() }
}
/** The track stays disabled throughout suspended negotiation, even when mute changes mid-publish. */
internal class CallMicrophone {
    @Volatile var muted=false
        private set
    @Volatile private var ready=false
    private val publication=Mutex()
    fun appMute(value: Boolean) { muted=value }
    fun systemMute(value: Boolean) { muted=value }
    suspend fun publish(publishDisabled: suspend ()->Unit, setEnabled: (Boolean)->Unit) = publication.withLock {
        ready=false
        setEnabled(false)
        publishDisabled()
        ready=true
        update(setEnabled)
    }
    fun update(setEnabled: (Boolean)->Unit) { if(ready) setEnabled(!muted) }
}
internal class ForegroundMicrophones {
    private val calls=java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    fun activate(id: String) { calls.add(id) }
    fun end(id: String) { calls.remove(id) }
    fun clear() { calls.clear() }
    fun needed(): Boolean = calls.isNotEmpty()
}
internal fun CallSnapshot.deadline(): Instant? = when(state) {
    "CREATING", "CONNECTING" -> mediaExpiresAt
    "RINGING" -> ringingExpiresAt
    else -> null
}
/** Server observation plus monotonic elapsed time avoids wall-clock skew and later clock changes. */
internal class ServerClock(private val wall: ()->Instant = Instant::now, private val nanos: ()->Long = System::nanoTime) {
    private data class Anchor(val server: Instant,val nanos: Long)
    @Volatile private var anchor: Anchor?=null
    @Synchronized fun observe(serverTime: Instant) {
        val previous=anchor
        val monotonic=nanos()
        val current=previous?.let { it.server.plusNanos((monotonic-it.nanos).coerceAtLeast(0)) }
        anchor=Anchor(if(current!=null && current.isAfter(serverTime)) current else serverTime,monotonic)
    }
    fun now(): Instant { val observed=anchor ?: return wall(); return observed.server.plusNanos((nanos()-observed.nanos).coerceAtLeast(0)) }
    val synchronized: Boolean get() = anchor!=null
}
