package vn.caresoft.customervoice

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.io.IOException
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.Instant
import java.util.concurrent.TimeUnit

internal class Credentials(val userId: String, val sessionId: String, val accessToken: String,
    val refreshToken: String, val expiresAt: Instant, val refreshExpiresAt: Instant) {
    val info get() = SessionInfo(userId,sessionId,expiresAt)
    fun json() = JSONObject().put("user_id",userId).put("session_id",sessionId).put("access_token",accessToken)
        .put("refresh_token",refreshToken).put("expires_at",expiresAt.toString()).put("refresh_expires_at",refreshExpiresAt.toString())
    override fun toString() = "Credentials(REDACTED)"
    companion object {
        fun parse(j: JSONObject) = Credentials(j.getString("user_id"),j.getString("session_id"),j.getString("access_token"),
            j.getString("refresh_token"),Instant.parse(j.getString("expires_at")),Instant.parse(j.getString("refresh_expires_at")))
    }
}
internal class VoiceApi(private val base: String, private val appId: String,
    private val credentials: () -> Credentials?, private val save: (Credentials) -> Unit,
    private val invalidated: (String) -> Unit, private val epoch: ()->Long = {0L}) {
    val client = OkHttpClient.Builder().retryOnConnectionFailure(false).followRedirects(false)
        .callTimeout(15,TimeUnit.SECONDS).build()
    val clock=ServerClock()
    private val refreshMutex = Mutex()
    suspend fun raw(method: String, path: String, body: JSONObject? = null, bearer: String? = null, requestId: String? = null): JSONObject {
        val b=Request.Builder().url(base.trimEnd('/')+path)
        if(bearer!=null) b.header("Authorization","Bearer $bearer")
        if(requestId!=null) b.header("X-Request-Id",requestId)
        b.method(method,if(method in setOf("POST","PUT","PATCH")) (body ?: JSONObject()).toString().toRequestBody("application/json".toMediaType()) else null)
        return suspendCancellableCoroutine { continuation ->
            val call=client.newCall(b.build())
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object: Callback {
                override fun onFailure(call: Call,e: IOException) { if(continuation.isActive) continuation.resumeWithException(e) }
                override fun onResponse(call: Call,response: Response) {
                    val result=runCatching { response.use {
                        val text=it.body?.string().orEmpty()
                        val envelope=if(text.isBlank()) JSONObject() else runCatching { JSONObject(text) }.getOrElse { throw VoiceException("INVALID_SERVER_RESPONSE",response.code) }
                        envelope.optionalString("server_time")?.let { time -> runCatching { clock.observe(Instant.parse(time)) } }
                        if(!it.isSuccessful) throw VoiceException(envelope.optJSONObject("error")?.optString("code") ?: "HTTP_${it.code}",it.code)
                        envelope.optJSONObject("data") ?: JSONObject()
                    } }
                    if(continuation.isActive) result.fold({continuation.resume(it)},{continuation.resumeWithException(it)})
                }
            })
        }
    }
    suspend fun revokeCaptured(old: Credentials) {
        try { raw("DELETE","/sessions/current",bearer=old.accessToken) }
        catch(e: VoiceException) {
            if(e.status!=401) throw e
            // Rotate only the captured old session. Never save it into the current session/store.
            val rotated=Credentials.parse(raw("POST","/sessions/refresh",JSONObject().put("app_id",appId)
                .put("session_id",old.sessionId).put("refresh_token",old.refreshToken)))
            if(rotated.sessionId!=old.sessionId) throw VoiceException("INVALID_SERVER_RESPONSE")
            raw("DELETE","/sessions/current",bearer=rotated.accessToken)
        }
    }
    private fun checkSession(expectedEpoch: Long,session: String) {
        if(epoch()!=expectedEpoch || credentials()?.sessionId!=session) throw VoiceException("SESSION_CHANGED")
    }
    suspend fun token(): String {
        val version=epoch(); val session=credentials()?.sessionId ?: throw VoiceException("LOGIN_REQUIRED")
        return fresh(false,null,version,session).accessToken
    }
    private suspend fun fresh(force: Boolean, rejectedToken: String?, version: Long, session: String): Credentials = refreshMutex.withLock {
        checkSession(version,session)
        val current=credentials() ?: throw VoiceException("LOGIN_REQUIRED")
        if((!force && (!clock.synchronized || current.expiresAt.isAfter(clock.now().plusSeconds(30)))) ||
            (force && current.accessToken != rejectedToken)) return@withLock current
        try {
            if(clock.synchronized && !current.refreshExpiresAt.isAfter(clock.now())) throw VoiceException("REFRESH_EXPIRED",401)
            val next=Credentials.parse(raw("POST","/sessions/refresh",JSONObject().put("app_id",appId)
                .put("session_id",current.sessionId).put("refresh_token",current.refreshToken)))
            checkSession(version,session)
            if(credentials() !== current) throw VoiceException("SESSION_CHANGED")
            if(next.sessionId!=current.sessionId || next.userId!=current.userId) throw VoiceException("INVALID_SERVER_RESPONSE")
            save(next); next
        } catch(e: Exception) {
            // Network failures and cancellation keep the session for bounded call recovery.
            if(e is VoiceException && e.status in setOf(401,403) && epoch()==version && credentials() === current) invalidated("LOGIN_REQUIRED")
            throw e
        }
    }
    suspend fun auth(method: String, path: String, body: JSONObject? = null, requestId: String? = null): JSONObject {
        val version=epoch(); val session=credentials()?.sessionId ?: throw VoiceException("LOGIN_REQUIRED")
        val used=fresh(false,null,version,session).accessToken
        return try { raw(method,path,body,used,requestId).also { checkSession(version,session) } } catch(e: VoiceException) {
            checkSession(version,session)
            if((e.status==403 && path=="/calls?filter=active") || e.code in setOf("SESSION_REVOKED","APP_DISABLED","SESSION_EXPIRED")) { invalidated(e.code); throw e }
            if(e.status!=401) throw e
            val next=fresh(true,used,version,session)
            try { raw(method,path,body,next.accessToken,requestId).also { checkSession(version,session) } } catch(second: VoiceException) {
                checkSession(version,session)
                if(second.status==401 || second.code in setOf("SESSION_REVOKED","APP_DISABLED")) invalidated(second.code)
                throw second
            }
        }
    }
}
internal fun JSONObject.optionalString(key: String): String? = if(isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
internal fun JSONObject.optionalInstant(key: String): Instant? = optionalString(key)?.let(Instant::parse)
internal fun callBody(businessNumber: String): JSONObject {
    require(businessNumber.matches(Regex("\\+?[0-9]{1,32}"))) { "Business number must contain 1-32 digits with an optional leading +" }
    return JSONObject().put("business_number",businessNumber)
}
internal fun snapshot(j: JSONObject) = CallSnapshot(j.getString("call_id"),j.getString("direction"),j.getString("state"),j.getLong("version"),
    j.optionalString("business_number"),j.optionalInstant("ringing_expires_at"),
    j.optionalInstant("media_expires_at"),j.optionalInstant("ended_at"),j.optionalString("end_reason"),j.optionalString("device_status"),j.optBoolean("is_owner"))
