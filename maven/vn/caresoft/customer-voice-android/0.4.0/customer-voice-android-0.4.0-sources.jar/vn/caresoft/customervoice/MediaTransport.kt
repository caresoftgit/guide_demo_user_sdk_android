package vn.caresoft.customervoice

import io.livekit.android.room.Room
import kotlinx.coroutines.*
import livekit.org.webrtc.RTCStatsReport
import kotlin.coroutines.resume

/** Publication ACK alone does not prove the microphone's publisher transport is ready. */
internal fun publisherConnected(report: RTCStatsReport): Boolean {
    val values=report.statsMap
    return values.values.any { transport ->
        if(transport.type!="transport" || transport.members["dtlsState"]!="connected") false
        else {
            val pair=values[transport.members["selectedCandidatePairId"] as? String]
            pair?.type=="candidate-pair" && pair.members["state"]=="succeeded"
        }
    }
}
internal fun mediaConnected(primaryState: Room.State,report: RTCStatsReport): Boolean =
    primaryState==Room.State.CONNECTED && publisherConnected(report)

internal suspend fun awaitPublisherConnected(room: Room) {
    withTimeout(8000) {
        while(true) {
            val connected=withTimeoutOrNull(1000) {
                suspendCancellableCoroutine<Boolean> { continuation ->
                    room.getPublisherRTCStats { report -> if(continuation.isActive) continuation.resume(mediaConnected(room.state,report)) }
                }
            } ?: false
            if(connected) return@withTimeout
            delay(200)
        }
    }
}
