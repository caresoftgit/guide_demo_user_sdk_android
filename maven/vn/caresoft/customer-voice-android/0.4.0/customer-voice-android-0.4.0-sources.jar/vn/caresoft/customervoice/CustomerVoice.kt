package vn.caresoft.customervoice

import android.Manifest
import android.content.Context
import android.app.NotificationManager
import androidx.core.app.NotificationManagerCompat
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import io.livekit.android.*
import io.livekit.android.audio.NoAudioHandler
import io.livekit.android.events.RoomEvent
import io.livekit.android.room.Room
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.LocalAudioTrack
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.*
import org.json.JSONObject
import java.time.Instant
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Kotlin suspend API. Initialize once in Application; native calls outlive Activity instances. */
object CustomerVoice {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private val _sessionState=MutableStateFlow<SessionState>(SessionState.LoggedOut)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()
    private val _calls=MutableStateFlow<List<CallSnapshot>>(emptyList())
    val calls: StateFlow<List<CallSnapshot>> = _calls.asStateFlow()
    private val _readiness=MutableStateFlow(VoiceReadiness())
    val readiness: StateFlow<VoiceReadiness> = _readiness.asStateFlow()
    private val _audioStates=MutableStateFlow<Map<String,CallAudioState>>(emptyMap())
    val audioStates: StateFlow<Map<String,CallAudioState>> = _audioStates.asStateFlow()
    private val _connectionStates=MutableStateFlow<Map<String,CallConnectionState>>(emptyMap())
    val connectionStates: StateFlow<Map<String,CallConnectionState>> = _connectionStates.asStateFlow()
    private val recoveries=ConcurrentHashMap<String,CallRecovery>()
    private val recoveryJobs=ConcurrentHashMap<String,Job>()
    private var networkMonitor: VoiceNetworkMonitor?=null
    private var observation: ReadinessObservation?=null
    private var readinessExpiry: Job?=null
    private val readinessMutex=Mutex()
    private var controlConnected=false
    private val _events=MutableSharedFlow<VoiceEvent>(extraBufferCapacity=64)
    val events: SharedFlow<VoiceEvent> = _events.asSharedFlow()
    private lateinit var context: Context
    private lateinit var config: VoiceConfig
    private lateinit var store: SecureSessionStore
    private lateinit var api: VoiceApi
    private lateinit var native: NativeCalls
    @Volatile private var credentials: Credentials? = null
    private val fence=SessionFence()
    private val ledger=CallLedger()
    private val rooms=ConcurrentHashMap<String,Room>()
    private val retiredRooms=ConcurrentHashMap<String,MutableList<Room>>()
    private val deadlines=ConcurrentHashMap<String,Job>()
    private val mediaJobs=ConcurrentHashMap<String,Job>()
    private val microphones=ConcurrentHashMap<String,CallMicrophone>()
    private val callEpochs=ConcurrentHashMap<String,Long>()
    private val actionMutex=Mutex()
    private val loginMutex=Mutex()
    private var socket: WebSocket?=null
    private var connection: Job?=null
    private val stopped=ConcurrentHashMap.newKeySet<String>()

    @Synchronized fun initialize(context: Context, config: VoiceConfig) {
        if(::config.isInitialized && this.config==config) return
        check(!::config.isInitialized || credentials==null) { "Logout before changing voice configuration" }
        val debug=(context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE)!=0
        validateBackend(config.backendUrl,config.allowDebugLoopback && debug)
        require(config.appId.isNotBlank())
        val epoch=fence.advance()
        this.context=context.applicationContext; this.config=config
        store=SecureSessionStore(this.context,"${config.backendUrl}|${config.accountId}|${config.appId}")
        api=VoiceApi(config.backendUrl.trimEnd('/')+"/${config.accountId}/api/v1/voice",config.appId,{credentials},{save(it)},{invalidate(it)},fence::capture)
        native=NativeCalls(this.context,config,scope,
            answer={id,_ -> telecomAnswer(id)},
            disconnect={id -> if(currentCall(id)) nativeDisconnect(id,fence.capture())},
            haltMedia={id -> if(currentCall(id)) stopMedia(id)},
            muted={id,value -> if(currentCall(id) && id !in stopped) { val mic=microphones.computeIfAbsent(id) {CallMicrophone()}; mic.systemMute(value); publishAudio(id); updateMicrophone(id,fence.capture(),false) }},
            audioChanged={id,_ -> if(currentCall(id) && id !in stopped) publishAudio(id)},
            failed={id,_ -> val ticket=callEpochs[id]; if(ticket!=null) scope.launch { if(fence.current(ticket)) { emitError("NATIVE_CALL_FAILED",id); cleanupFailedMedia(id,ticket) } }}, isCurrent={id -> currentCall(id) && id !in stopped}, now={api.clock.now()})
        store.load()?.let { fence.commit(epoch) { save(it); startConnection(epoch) } }
        publishReadiness()
    }
    private fun requireInitialized() { check(::api.isInitialized) { "Call CustomerVoice.initialize from Application first" } }
    private fun sessionEpoch(): Long { requireInitialized(); if(credentials==null) throw VoiceException("LOGIN_REQUIRED"); return fence.capture() }
    private fun currentCall(id: String): Boolean = credentials!=null && callEpochs[id]?.let(fence::current)==true
    private fun save(next: Credentials) { store.save(next); credentials=next; _sessionState.value=SessionState.Authenticated(next.info); publishReadiness() }
    private fun invalidate(code: String) {
        val epoch=fence.advance()
        credentials=null; observation=null; readinessExpiry?.cancel(); controlConnected=false
        store.clear(); connection?.cancel(); socket?.cancel(); socket=null; publishReadiness()
        _sessionState.value=SessionState.LoginRequired(code)
        val oldIds=ledger.values().map { it.callId }; val oldNative=native
        oldIds.forEach { stopMedia(it) }; callEpochs.clear(); ledger.clear(); _calls.value=emptyList(); _audioStates.value=emptyMap(); publishReadiness()
        scope.launch { oldIds.forEach { oldNative.remove(it) }; fence.commit(epoch) { emitError(code) } }
    }
    suspend fun login(userId: String, tenantApiToken: String): SessionInfo = withContext(Dispatchers.Main.immediate) {
        requireInitialized(); require(userId.matches(Regex("[0-9]+")) && userId.any { it!='0' }); require(tenantApiToken.isNotBlank())
        val old=credentials; val client=api
        invalidate("LOGIN_PENDING"); val epoch=fence.capture()
        loginMutex.withLock {
            fence.check(epoch)
            // Revoke only the captured old session; a late logout must never use a new user's bearer.
            if(old!=null) runCatching { client.revokeCaptured(old) }
            fence.check(epoch)
            val version=context.packageManager.getPackageInfo(context.packageName,0).versionName.orEmpty()
            val data=client.raw("POST","/sessions",JSONObject().put("account_id",config.accountId).put("app_id",config.appId).put("application_id",context.packageName)
                .put("user_id",userId).put("installation_id",store.installationId).put("os","android")
                .put("os_version",android.os.Build.VERSION.RELEASE).put("sdk_version","0.4.0").put("app_version",version),tenantApiToken)
            fence.check(epoch)
            Credentials.parse(data).also { fence.commit(epoch) { save(it); startConnection(epoch) } }.info
        }
    }
    suspend fun logout(): Unit = withContext(Dispatchers.Main.immediate) {
        requireInitialized(); val old=credentials; val client=api
        invalidate("LOGGED_OUT"); _sessionState.value=SessionState.LoggedOut
        // Local cleanup is immediate. The captured bearer cannot revoke a replacement login.
        if(old!=null) client.revokeCaptured(old)
    }
    suspend fun updatePushToken(fcmToken: String): Unit = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch(); require(fcmToken.isNotBlank()); api.auth("PUT","/installations/current/push",JSONObject().put("token",fcmToken).put("application_id",context.packageName)); fence.check(epoch); checkReadiness()
    }
    suspend fun unregisterPushToken(): Unit = withContext(Dispatchers.Main.immediate) { val epoch=sessionEpoch(); api.auth("DELETE","/installations/current/push"); fence.check(epoch); observation=null; publishReadiness(); checkReadiness() }
    suspend fun call(businessNumber: String): CallSnapshot = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch()
        actionMutex.withLock {
            fence.check(epoch); microphonePermission(); val body=callBody(businessNumber)
            val requestId=UUID.randomUUID().toString()
            val data=try { api.auth("POST","/calls",body,requestId) }
            catch(e: Exception) { if(fence.current(epoch)) { runCatching { reconcile(epoch) }; emitError("CALL_OUTCOME_UNKNOWN_REQUEST_$requestId") }; throw e }
            val call=apply(snapshot(data),epoch)
            try { native.add(call); fence.check(epoch); join(call,false,epoch) }
            catch(e: Exception) { if(fence.current(epoch)) cleanupFailedMedia(call.callId,epoch); throw e }
            call
        }
    }
    suspend fun answer(callId: String): Unit = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch()
        actionMutex.withLock {
            val call=claimAnswer(callId,epoch)
            try { native.add(call); fence.check(epoch); join(call,false,epoch) }
            catch(e: Exception) { if(fence.current(epoch)) cleanupFailedMedia(callId,epoch); throw e }
        }
    }
    /** Telecom needs the callback to return before it marks the call active; media must follow it. */
    private suspend fun telecomAnswer(id: String) = withContext(Dispatchers.Main.immediate) {
        val epoch=callEpochs[id] ?: throw VoiceException("SESSION_CHANGED"); fence.check(epoch)
        val call=try { withTimeout(4000) { actionMutex.withLock { claimAnswer(id,epoch) } } }
        catch(e: Exception) { if(fence.current(epoch)) scope.launch { cleanupFailedMedia(id,epoch) }; throw e }
        scope.launch {
            yield() // Return the successful server claim to Telecom before starting room connection.
            if(fence.current(epoch)) try { join(call,true,epoch) } catch(e: Exception) { if(fence.current(epoch)) cleanupFailedMedia(id,epoch) }
        }
    }
    private suspend fun claimAnswer(id: String, epoch: Long): CallSnapshot {
        fence.check(epoch); microphonePermission()
        if(id in stopped) throw VoiceException("CALL_ENDED_LOCALLY")
        val before=fetch(id,epoch)
        if(id in stopped) throw VoiceException("CALL_ENDED_LOCALLY")
        if(!before.canRing(api.clock.now()) && before.deviceStatus!="winner") throw VoiceException("CALL_NOT_RINGING")
        val next=apply(snapshot(api.auth("POST","/calls/${path(id)}/answer",requestId=UUID.randomUUID().toString())),epoch)
        if(id in stopped) throw VoiceException("CALL_ENDED_LOCALLY")
        if(next.terminal || next.lost) throw VoiceException("ANSWERED_ELSEWHERE")
        return next
    }
    suspend fun reject(callId: String): Unit = withContext(Dispatchers.Main.immediate) { mutate(callId,"reject",sessionEpoch()) }
    suspend fun hangup(callId: String): Unit = withContext(Dispatchers.Main.immediate) { mutate(callId,"hangup",sessionEpoch()) }
    private suspend fun mutate(id: String, operation: String, epoch: Long) {
        fence.check(epoch)
        stop(id) // Stop microphone and close local UI before waiting for a control response.
        fence.check(epoch)
        apply(snapshot(api.auth("POST","/calls/${path(id)}/$operation",requestId=UUID.randomUUID().toString())),epoch)
    }
    private suspend fun nativeDisconnect(id: String,epoch: Long) {
        fence.check(epoch); val ringing=ledger.values().firstOrNull { it.callId==id }?.canRing(api.clock.now())==true
        stop(id); if(fence.current(epoch)) runCatching { mutate(id,if(ringing) "reject" else "hangup",epoch) }
    }
    suspend fun setMuted(callId: String, muted: Boolean): Unit = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch()
        if(!currentCall(callId) || callId in stopped) throw VoiceException("CALL_ENDED_LOCALLY")
        val mic=microphones.computeIfAbsent(callId) {CallMicrophone()}
        context.getSystemService(android.media.AudioManager::class.java).isMicrophoneMute=muted
        mic.appMute(muted); publishAudio(callId); updateMicrophone(callId,epoch,false)
    }
    private suspend fun updateMicrophone(id: String,epoch: Long,publish: Boolean) {
        fence.check(epoch); val mic=microphones.computeIfAbsent(id) {CallMicrophone()}; val room=rooms[id] ?: return
        room.setMicrophoneMute(mic.muted)
        val participant=room.localParticipant
        val track=if(publish) participant.getOrCreateDefaultAudioTrack()
            else participant.getTrackPublication(Track.Source.MICROPHONE)?.track as? LocalAudioTrack ?: return
        val change: (Boolean)->Unit = { enabled ->
            fence.check(epoch)
            if(id in stopped || rooms[id]!==room) throw VoiceException("CALL_ENDED_DURING_JOIN")
            // Both writes are synchronous on Main: never enable a track during suspended negotiation.
            room.setMicrophoneMute(!enabled)
            track.enabled=enabled
            participant.getTrackPublication(Track.Source.MICROPHONE)?.muted=!enabled
        }
        if(publish) mic.publish({
            if(!participant.publishAudioTrack(track)) throw VoiceException("MICROPHONE_PUBLISH_FAILED")
            fence.check(epoch)
        },change) else mic.update(change)
        fence.check(epoch)
        _events.emit(VoiceEvent(if(publish) "media_published" else "mute_changed",id))
    }
    fun getAvailableAudioRoutes(callId: String): List<AudioRoute> { requireInitialized(); return native.routes(callId) }
    suspend fun selectAudioRoute(callId: String, route: AudioRoute): Unit = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch(); native.route(callId,route); fence.check(epoch); _events.emit(VoiceEvent("audio_route_changed",callId))
    }
    suspend fun sendDtmf(callId: String, digit: Char): Unit = withContext(Dispatchers.Main.immediate) {
        val epoch=sessionEpoch(); val code=dtmfCode(digit); val room=rooms[callId] ?: throw VoiceException("MEDIA_NOT_CONNECTED")
        room.localParticipant.publishDtmf(code,digit.toString()).getOrThrow(); fence.check(epoch)
    }
    /** Returns true for recognized voice messages, including discarded stale pushes. */
    fun handleRemoteMessage(data: Map<String,String>): Boolean {
        if(data["type"] !in setOf("voice.incoming","voice.ended")) return false
        if(!::api.isInitialized) return true
        val epoch=fence.capture(); val session=credentials ?: return true; if(!fence.current(epoch)) return true; val clock=api.clock
        // Before a server clock observation, fetch authoritative state rather than trusting a skewed wall clock.
        val now=if(clock.synchronized) clock.now() else runCatching { Instant.parse(data["expires_at"]).minusNanos(1) }.getOrElse { return true }
        if(!PushGate.accepts(data,session.sessionId,config.appId,now)) return true
        scope.launch { if(fence.current(epoch)) runCatching { presentIncoming(fetch(data.getValue("call_id"),epoch),epoch) }
            .onFailure { if(fence.current(epoch)) emitError("PUSH_RECONCILE_FAILED",data["call_id"]) } }
        return true
    }
    private suspend fun fetch(id: String,epoch: Long): CallSnapshot { fence.check(epoch); return apply(snapshot(api.auth("GET","/calls/${path(id)}")),epoch) }
    private suspend fun reconcile(epoch: Long) {
        fence.check(epoch); val data=api.auth("GET","/calls?filter=active"); fence.check(epoch); val array=data.getJSONArray("calls")
        val active=mutableSetOf<String>()
        for(i in 0 until array.length()) { val c=apply(snapshot(array.getJSONObject(i)),epoch); active.add(c.callId); presentIncoming(c,epoch) }
        ledger.values().filter { !it.terminal && it.callId !in active }.forEach { old ->
            try { fetch(old.callId,epoch) } catch(e: VoiceException) { fence.check(epoch); if(e.status==404 || e.status==410) stop(old.callId) else throw e }
        }
        checkReadiness()
    }
    private suspend fun apply(next: CallSnapshot,epoch: Long): CallSnapshot {
        fence.check(epoch)
        fence.commit(epoch) { ledger.apply(next); callEpochs[next.callId]=epoch; _calls.value=ledger.visible(stopped); publishReadiness() }
        fence.check(epoch); val current=ledger.values().first { it.callId==next.callId }
        if(current.terminal || current.lost) stop(current.callId)
        else if(current.callId !in stopped) { scheduleDeadline(current,epoch); if(rooms.containsKey(current.callId)) native.show(current) }
        return current
    }
    private suspend fun presentIncoming(call: CallSnapshot,epoch: Long) {
        fence.check(epoch)
        if(call.canRing(api.clock.now()) && call.callId !in stopped) {
            try { native.add(call); fence.check(epoch) } catch(e: Exception) { if(fence.current(epoch)) { emitError("INCOMING_NATIVE_FAILED",call.callId); stop(call.callId) } }
        }
    }
    private fun scheduleDeadline(call: CallSnapshot,epoch: Long) {
        val expiry=call.deadline(); deadlines.remove(call.callId)?.cancel()
        if(expiry!=null) deadlines[call.callId]=scope.launch {
            delay(java.time.Duration.between(api.clock.now(),expiry).toMillis().coerceAtLeast(0))
            if(fence.current(epoch)) { deadlines.remove(call.callId); stop(call.callId); emitError("CALL_DEADLINE_EXPIRED",call.callId); runCatching { fetch(call.callId,epoch) } }
        }
    }
    private suspend fun join(call: CallSnapshot,fromTelecom: Boolean,epoch: Long) {
        fence.check(epoch)
        if(call.callId in stopped || call.terminal || call.lost || (!call.isOwner && call.deviceStatus!="winner")) throw VoiceException("MEDIA_NOT_AUTHORIZED")
        if(rooms.containsKey(call.callId)) return
        native.activate(call.callId,call.direction=="INBOUND",fromTelecom); fence.check(epoch)
        val id=call.callId
        val recovery=CallRecovery(scope,{ state ->
            if(fence.current(epoch) && id !in stopped) {
                _connectionStates.value=_connectionStates.value+(id to state)
                _events.tryEmit(VoiceEvent("connection_changed",id,state.name))
            }
        },{
            if(fence.current(epoch) && id !in stopped) {
                emitError("NETWORK_RECOVERY_TIMEOUT",id)
                scope.launch { runCatching { mutate(id,"hangup",epoch) } }
            }
        })
        recoveries[id]=recovery
        _connectionStates.value=_connectionStates.value+(id to CallConnectionState.CONNECTING)
        if(networkMonitor==null) networkMonitor=VoiceNetworkMonitor(context,scope) {
            recoveries.keys.toList().forEach { beginRecovery(it) }
        }
        connectMedia(call,epoch,recovery,0)
    }
    private suspend fun connectMedia(call: CallSnapshot,epoch: Long,recovery: CallRecovery,ticket: Long) {
        val id=call.callId
        fun checkCurrent() {
            fence.check(epoch)
            if(id in stopped || recoveries[id]!==recovery || !recovery.current(ticket)) throw VoiceException("CALL_ENDED_DURING_JOIN")
        }
        checkCurrent()
        val grant=api.auth("POST","/calls/${path(id)}/media-token",requestId=UUID.randomUUID().toString()); checkCurrent()
        if(!Instant.parse(grant.getString("expires_at")).isAfter(api.clock.now())) throw VoiceException("MEDIA_TOKEN_EXPIRED")
        val url=grant.getString("url"); val uri=java.net.URI(url)
        if(uri.scheme!="wss" && !(config.allowDebugLoopback && (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE)!=0 && uri.scheme=="ws" && uri.host in setOf("10.0.2.2","127.0.0.1","localhost"))) throw VoiceException("INSECURE_MEDIA_URL")
        val room=LiveKit.create(context,overrides=LiveKitOverrides(audioOptions=AudioOptions(audioHandler=NoAudioHandler(),disableCommunicationModeWorkaround=true)))
        rooms[id]=room
        mediaJobs[id]=scope.launch {
            room.events.events.collect { event -> if(fence.current(epoch) && rooms[id]===room && id !in stopped) when(event) {
                is RoomEvent.Disconnected -> {
                    if(recovery.hasConnected) beginRecovery(id)
                    else scope.launch { cleanupFailedMedia(id,epoch) }
                }
                is RoomEvent.Reconnecting -> beginRecovery(id)
                else -> Unit
            } }
        }
        room.connect(url,grant.getString("token"),ConnectOptions(audio=false,video=false)); checkCurrent()
        val fresh=fetch(id,epoch); checkCurrent()
        if(fresh.terminal || fresh.lost || rooms[id]!==room) throw VoiceException("CALL_ENDED_DURING_JOIN")
        microphonePermission(); updateMicrophone(id,epoch,true)
        awaitPublisherConnected(room); checkCurrent()
        if(recovery.connected(ticket)) releaseRetiredRooms(id)
    }
    private fun beginRecovery(id: String) {
        val recovery=recoveries[id] ?: return
        if(id in stopped || !currentCall(id) || !recovery.hasConnected) return
        recovery.begin()
        if(recoveryJobs[id]?.isActive==true) return
        val epoch=callEpochs[id] ?: return
        recoveryJobs[id]=scope.launch {
            while(isActive && fence.current(epoch) && id !in stopped && recovery.state==CallConnectionState.RECONNECTING) {
                val ticket=recovery.generation
                retireRoom(id,true)
                val call=ledger.values().firstOrNull { it.callId==id && !it.terminal && !it.lost } ?: return@launch
                try {
                    // A new transport joins the same authorized room/participant; never create another SIP call.
                    withTimeout(12000) { connectMedia(call,epoch,recovery,ticket) }
                    if(recovery.state==CallConnectionState.CONNECTED) return@launch
                } catch(e: TimeoutCancellationException) { /* Retry within the original 30-second deadline. */ }
                catch(e: CancellationException) { throw e }
                catch(_: Exception) { /* New media grant and transport on the next bounded attempt. */ }
                delay(1000)
            }
        }
    }
    private fun retireRoom(id: String,retainUntilReplacement: Boolean=false) {
        mediaJobs.remove(id)?.cancel()
        rooms.remove(id)?.let { room ->
            if(retainUntilReplacement) {
                // Do not send Leave before replacement joins: the SIP leg must stay in this room.
                room.setMicrophoneMute(true)
                (room.localParticipant.getTrackPublication(Track.Source.MICROPHONE)?.track as? LocalAudioTrack)?.enabled=false
                retiredRooms.computeIfAbsent(id) { mutableListOf() }.add(room)
            } else { room.disconnect();room.release() }
        }
        if(!retainUntilReplacement) releaseRetiredRooms(id)
    }
    private fun releaseRetiredRooms(id: String) {
        retiredRooms.remove(id)?.forEach { it.disconnect();it.release() }
    }
    private suspend fun cleanupFailedMedia(id: String,epoch: Long) {
        if(!fence.current(epoch)) return
        stop(id); if(fence.current(epoch)) { runCatching { mutate(id,"hangup",epoch) }; if(fence.current(epoch)) emitError("MEDIA_FAILED",id) }
    }
    private fun stopMedia(id: String) {
        stopped.add(id); deadlines.remove(id)?.cancel()
        recoveries.remove(id)?.stop(); recoveryJobs.remove(id)?.cancel(); retireRoom(id); microphones.remove(id)
        _calls.value=ledger.visible(stopped); _connectionStates.value=_connectionStates.value-id
        _audioStates.value=_audioStates.value-id
        if(recoveries.isEmpty()) { networkMonitor?.close(); networkMonitor=null }
        if(::native.isInitialized) native.mediaEnded(id)
        publishReadiness()
    }
    private suspend fun stop(id: String) { stopMedia(id); native.remove(id) }
    private fun startConnection(epoch: Long) {
        fence.check(epoch); connection?.cancel(); socket?.cancel()
        val client=api; val url=config.backendUrl.trimEnd('/')+"/${config.accountId}/api/v1/voice/events"
        connection=scope.launch {
            var attempt=0
            while(isActive && fence.current(epoch) && credentials!=null) {
                val signal=Channel<Unit>(Channel.CONFLATED); var ownSocket: WebSocket?=null
                try {
                    val token=client.token(); fence.check(epoch)
                    ownSocket=client.client.newWebSocket(Request.Builder().url(url).header("Authorization","Bearer $token").build(),object: WebSocketListener() {
                        override fun onOpen(webSocket: WebSocket,response: Response) { if(fence.current(epoch)) { scope.launch { if(fence.current(epoch)) { controlConnected=true; publishReadiness() } }; signal.trySend(Unit) } else webSocket.cancel() }
                        override fun onMessage(webSocket: WebSocket,text: String) {
                            scope.launch { if(fence.current(epoch)) runCatching {
                                val e=JSONObject(text)
                                if(e.optString("type") in setOf("session.revoked","app.disabled")) { fence.commit(epoch) { invalidate("SESSION_REVOKED") }; return@runCatching }
                                e.optionalString("call_id")?.let { presentIncoming(fetch(it,epoch),epoch) }
                            }.onFailure { if(fence.current(epoch)) emitError("EVENT_RECONCILE_FAILED") } }
                        }
                        private fun recheckAuth() { scope.launch { if(fence.current(epoch)) runCatching { client.auth("GET","/calls?filter=active") } } }
                        override fun onFailure(webSocket: WebSocket,t: Throwable,response: Response?) { signal.close(); if(response?.code in setOf(401,403)) recheckAuth() }
                        override fun onClosed(webSocket: WebSocket,code: Int,reason: String) { signal.close(); if(code==4401) recheckAuth() }
                    })
                    socket=ownSocket
                    withTimeout(15000) { signal.receive() }; reconcile(epoch); attempt=0
                    while(isActive && fence.current(epoch)) {
                        val closed=withTimeoutOrNull(15000) { signal.receiveCatching(); true } ?: false
                        if(closed) break
                        reconcile(epoch); if(credentials?.expiresAt?.isBefore(client.clock.now().plusSeconds(30))==true) break
                    }
                } catch(e: CancellationException) { throw e } catch(e: Exception) { if(fence.current(epoch)) emitError("CONTROL_RECONNECTING") }
                finally { ownSocket?.cancel(); if(socket===ownSocket) socket=null; signal.cancel(); if(fence.current(epoch)) { controlConnected=false; publishReadiness() } }
                delay((1000L shl attempt.coerceAtMost(4)).coerceAtMost(15000)); attempt++
            }
        }
    }
    /** Foreground reconciliation keeps stored sessions without treating a network failure as logout. */
    fun resume() {
        if(!::api.isInitialized || credentials==null) return
        val epoch=fence.capture()
        scope.launch { runCatching { reconcile(epoch) }.onFailure { if(fence.current(epoch)) emitError("RESUME_FAILED") } }
    }
    fun isCallPresentable(callId: String): Boolean = callId !in stopped && _calls.value.any {
        it.callId==callId && !it.terminal && !it.lost &&
            !(it.direction=="INBOUND" && it.state=="RINGING" && !it.canRing(currentTime()))
    }
    /** Server-adjusted clock for call presentation; falls back to device time until observed. */
    fun currentTime(): java.time.Instant = if(::api.isInitialized) api.clock.now() else java.time.Instant.now()
    /** Checks the current session; network errors return UNKNOWN without treating stored credentials as verified. */
    suspend fun checkReadiness(): VoiceReadiness = withContext(Dispatchers.Main.immediate) {
        if(!::api.isInitialized || credentials==null) { publishReadiness(); return@withContext _readiness.value }
        val epoch=fence.capture()
        readinessMutex.withLock {
            if(!fence.current(epoch) || credentials==null) return@withLock _readiness.value
            try {
                val data=api.auth("GET","/configuration"); fence.check(epoch)
                val session=credentials ?: throw VoiceException("LOGIN_REQUIRED")
                observation=readinessObservation(data,session,api.clock.now())
                val verified=observation
                readinessExpiry?.cancel()
                readinessExpiry=scope.launch {
                    delay(30000)
                    if(fence.current(epoch) && observation===verified) { observation=null; publishReadiness() }
                }
            } catch(e: CancellationException) { throw e }
            catch(e: Exception) { if(fence.current(epoch)) observation=null }
            if(fence.current(epoch)) publishReadiness()
            _readiness.value
        }
    }
    private fun publishReadiness() {
        if(!::context.isInitialized || credentials==null) { _readiness.value=VoiceReadiness(); return }
        val session=credentials ?: return
        val verified=observation?.takeIf { it.sessionId==session.sessionId }
        val notices=context.getSystemService(NotificationManager::class.java)
        val channel=notices.getNotificationChannel(NativeCalls.CHANNEL)
        val notifications=NotificationManagerCompat.from(context).areNotificationsEnabled() && channel?.importance!=NotificationManager.IMPORTANCE_NONE
        _readiness.value=evaluateReadiness(if(verified!=null) SessionStatus.VALID else SessionStatus.UNKNOWN,
            session.userId,verified?.voiceReady==true,verified?.pushRegistered==true,
            ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED,
            notifications,ledger.visible(stopped).any { !it.terminal && !it.lost },controlConnected,verified?.checkedAt)
    }
    private fun publishAudio(id: String) {
        _audioStates.value=_audioStates.value+(id to CallAudioState(microphones[id]?.muted ?: false,native.routes(id)))
    }
    private fun microphonePermission() {
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) throw VoiceException("MICROPHONE_PERMISSION_REQUIRED")
    }
    private fun path(id: String): String { require(id.isNotBlank()); return java.net.URLEncoder.encode(id,"UTF-8") }
    private fun emitError(code: String,id: String? = null) { _events.tryEmit(VoiceEvent("error",id,code)) }
    internal fun runAction(action: String,id: String,finished: ()->Unit) {
        val epoch=fence.capture()
        scope.launch { try { fence.check(epoch); when(action) { "answer" -> answer(id); "reject" -> reject(id); "hangup" -> hangup(id) } }
            catch(e: Exception) { if(fence.current(epoch)) emitError((e as? VoiceException)?.code ?: "NATIVE_ACTION_FAILED",id) }
            finally { finished() } }
    }
    internal fun nativeServiceFailed(id: String?, e: Exception) {
        val epoch=id?.let {callEpochs[it]} ?: return
        scope.launch { if(fence.current(epoch)) { emitError("FOREGROUND_SERVICE_DENIED",id); cleanupFailedMedia(id,epoch) } }
    }
}
