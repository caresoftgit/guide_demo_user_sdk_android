package vn.caresoft.customervoice

import java.time.Instant

enum class SessionStatus { LOGGED_OUT, VALID, UNKNOWN }

/** Eligibility at checkedAt, not a guarantee of push delivery or media connectivity. */
data class VoiceReadiness(
    val sessionStatus: SessionStatus = SessionStatus.LOGGED_OUT,
    val isLoggedIn: Boolean = false,
    val canCall: Boolean = false,
    val canReceive: Boolean = false,
    val userId: String? = null,
    val reasons: List<String> = listOf("LOGIN_REQUIRED"),
    val checkedAt: Instant? = null,
    val controlConnected: Boolean = false
)

internal fun evaluateReadiness(status: SessionStatus, userId: String?, voiceReady: Boolean,
    pushRegistered: Boolean, microphoneGranted: Boolean, notificationsAllowed: Boolean,
    busy: Boolean, controlConnected: Boolean, checkedAt: Instant?): VoiceReadiness {
    val verified=status==SessionStatus.VALID
    val reasons=buildList {
        if(status==SessionStatus.LOGGED_OUT) add("LOGIN_REQUIRED")
        if(status==SessionStatus.UNKNOWN) add("SESSION_UNVERIFIED")
        if(verified && !voiceReady) add("VOICE_NOT_READY")
        if(!microphoneGranted) add("MICROPHONE_PERMISSION_REQUIRED")
        if(!notificationsAllowed) add("NOTIFICATIONS_DISABLED")
        if(verified && !pushRegistered) add("PUSH_NOT_REGISTERED")
        if(busy) add("CALL_IN_PROGRESS")
    }
    val available=verified && voiceReady && microphoneGranted && !busy
    return VoiceReadiness(status,verified,available,available && pushRegistered && notificationsAllowed,
        userId,reasons,checkedAt,controlConnected)
}

internal fun selectedRoutes(routes: List<AudioRoute>, observedEndpoint: String?): List<AudioRoute> =
    routes.map { it.copy(selected=it.id==observedEndpoint) }

internal data class ReadinessObservation(val sessionId: String, val voiceReady: Boolean,
    val pushRegistered: Boolean, val checkedAt: Instant)

internal fun readinessObservation(data: org.json.JSONObject, credentials: Credentials, checkedAt: Instant): ReadinessObservation? {
    if(data.optString("session_id")!=credentials.sessionId || data.optString("user_id")!=credentials.userId ||
        data.opt("voice_ready") !is Boolean || data.opt("push_registered") !is Boolean) return null
    return ReadinessObservation(credentials.sessionId,data.getBoolean("voice_ready"),data.getBoolean("push_registered"),checkedAt)
}
