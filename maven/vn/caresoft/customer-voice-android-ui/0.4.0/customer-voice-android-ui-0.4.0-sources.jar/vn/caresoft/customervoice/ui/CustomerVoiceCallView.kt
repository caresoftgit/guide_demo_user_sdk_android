package vn.caresoft.customervoice.ui

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import kotlinx.coroutines.*
import vn.caresoft.customervoice.*
import androidx.core.telecom.CallEndpointCompat
import android.os.SystemClock
import android.Manifest
import android.content.pm.PackageManager

/**
 * Reusable incoming/outgoing call screen. bind/unbind never starts, ends, or disposes a call.
 * The host owns runtime permissions and should call unbind when leaving the screen.
 */
class CustomerVoiceCallView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {
    private val accent = Color.rgb(8, 126, 117)
    private val ink = Color.rgb(24, 47, 53)
    private val secondary = Color.rgb(100, 117, 122)
    private val red = Color.rgb(220, 57, 70)
    private var callId: String? = null
    private var subscription: Job? = null
    private var bindingGeneration = 0L
    private var actionState = CustomerVoiceUi.ActionState()
    internal var requestMicrophone: (() -> Unit)? = null
    private var pendingAnswer: String? = null
    private var snapshot: CallSnapshot? = null
    internal var onCallEnded: (() -> Unit)? = null
    private var connection: CallConnectionState? = null
    private var audio = CallAudioState()
    private var routes = emptyList<AudioRoute>()
    private var routeDialog: AlertDialog? = null
    private val busy: Boolean get() = actionState.busy
    private var keypadOpen = false
    private var keypadReveal: ViewTreeObserver.OnGlobalLayoutListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { snapshot?.let(::render); if (callId != null) handler.postDelayed(this, 1000) }
    }
    private val body = LinearLayout(context).apply {
        orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(20), dp(24), dp(20), dp(20))
    }
    private val scroll = ScrollView(context).apply {
        isFillViewport = true; clipToPadding = false
        addView(body, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
    }
    private val direction = label(11, accent, bold = true)
    private val title = label(30, ink, bold = true).apply { setTextIsSelectable(true) }
    private val number = label(18, secondary)
    private val status = label(15, accent, bold = true).apply { accessibilityLiveRegion = ACCESSIBILITY_LIVE_REGION_POLITE }
    private val duration = label(22, ink).apply { typeface = Typeface.MONOSPACE }
    private val line = label(12, secondary).apply {
        setPadding(dp(14), dp(8), dp(14), dp(8)); background = shape(Color.WHITE, 24)
    }
    private val reason = label(14, secondary)
    private val error = label(13, red).apply {
        setPadding(dp(12), dp(12), dp(12), dp(12)); background = shape(Color.rgb(255, 236, 237), 14)
        accessibilityLiveRegion = ACCESSIBILITY_LIVE_REGION_POLITE; visibility = GONE
    }
    private val progress = label(12, secondary).apply { text = "Đang xử lý…"; visibility = GONE }
    private val controls = LinearLayout(context).apply { orientation = VERTICAL }
    private val keypad = LinearLayout(context).apply { orientation = VERTICAL; visibility = GONE }
    private val mute = control("Tắt mic", "mic") { perform { CustomerVoice.setMuted(it, !(CustomerVoice.audioStates.value[it]?.muted ?: false)) } }
    private val keys = control("Bàn phím", "keypad") {
        keypadOpen = !keypadOpen; snapshot?.let(::render)
        revealKeypadAfterLayout()
    }
    private val route = control("Âm thanh", "receiver") { showRoutes() }
    private val terminal = LinearLayout(context).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(16))
        setBackgroundColor(Color.rgb(244, 247, 247))
    }
    private val end = control("Kết thúc", "end", red, terminal = true) {
        perform() { current ->
            if (snapshot?.let { CallPresentation(it, CustomerVoice.currentTime()).incoming } == true) CustomerVoice.reject(current) else CustomerVoice.hangup(current)
        }
    }
    private val answer = control("Trả lời", "phone", accent, terminal = true) { answerCall() }
    /** Optional caller-ID/line caption. Changing it never changes the call's callerId. */
    var lineLabel: String? = null
        set(value) { field = value; line.text = value; line.visibility = if (value.isNullOrBlank()) GONE else VISIBLE }

    init {
        orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(232, 245, 242), Color.rgb(244, 247, 247))).apply { cornerRadius = dp(28).toFloat() }
        clipToOutline = true
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        addView(terminal, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        body.addView(direction, spaced(0, 18))
        body.addView(CallGlyph(context, "person", accent).apply {
            background = shape(Color.rgb(216, 237, 231), 48)
        }, LayoutParams(dp(88), dp(88)).apply { bottomMargin = dp(16) })
        body.addView(title, spaced(0, 8))
        body.addView(number, spaced(0, 8))
        body.addView(status, spaced(0, 8))
        body.addView(duration, spaced(0, 8))
        body.addView(line, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(20) })
        controls.addView(row(mute, keys, route))
        body.addView(controls, spaced(4, 8))
        listOf("123", "456", "789", "*0#").forEach { digits ->
            keypad.addView(row(*digits.map { digit ->
                Button(context).apply {
                    text = digit.toString(); textSize = 24f; isAllCaps = false
                    setTextColor(ink); minHeight = dp(52); minimumHeight = dp(52)
                    background = ripple(Color.WHITE, 28)
                    contentDescription = "Phím $digit"
                    setOnClickListener { perform { CustomerVoice.sendDtmf(it, digit) } }
                }
            }.toTypedArray()))
        }
        body.addView(keypad, spaced(0, 12))
        body.addView(reason, spaced(8, 12)); body.addView(progress, spaced(8, 8)); body.addView(error, spaced(8, 0))
        listOf(end, answer).forEach { terminal.addView(it, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)) }
        controls.visibility = GONE; terminal.visibility = GONE
        number.visibility = GONE; duration.visibility = GONE; line.visibility = GONE; reason.visibility = GONE
        status.text = "Chưa có cuộc gọi"
    }

    /** Binding only observes. It never creates, answers or ends a call. */
    fun bind(callId: String) {
        unbind(); this.callId=callId; scroll.scrollTo(0,0)
        if(isAttachedToWindow) observe()
    }
    fun unbind() {
        subscription?.cancel(); subscription=null; callId=null; bindingGeneration++
        handler.removeCallbacks(tick); routeDialog?.dismiss(); routeDialog=null
        cancelKeypadReveal(); pendingAnswer=null
        snapshot=null; connection=null; actionState=CustomerVoiceUi.ActionState(); keypadOpen=false; audio=CallAudioState(); routes=emptyList()
        controls.visibility=GONE; keypad.visibility=GONE; terminal.visibility=GONE
        error.visibility=GONE; progress.visibility=GONE
        title.text=""; direction.text=""; status.text="Chưa có cuộc gọi"
        number.visibility=GONE; duration.visibility=GONE; reason.visibility=GONE
    }
    private fun observe() {
        subscription?.cancel()
        val id=callId ?: return
        val generation=bindingGeneration
        subscription=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate).launch {
            launch { CustomerVoice.calls.collect { values ->
                if(!isBound(id,generation)) return@collect
                val current=values.firstOrNull { it.callId==id }
                if(current!=null) render(current)
                else {
                    snapshot=null; controls.visibility=GONE; terminal.visibility=GONE; keypad.visibility=GONE
                    duration.visibility=GONE; status.text="Cuộc gọi không còn khả dụng"
                    onCallEnded?.invoke()
                }
            } }
            launch { CustomerVoice.connectionStates.collect {
                if(isBound(id,generation)) { connection=it[id];snapshot?.let(::render) }
            } }
            launch { CustomerVoice.audioStates.collect {
                if(isBound(id,generation)) { renderAudio(it[id] ?: CallAudioState()) }
            } }
            launch { CustomerVoiceUi.actions.collect {
                if(isBound(id,generation)) { actionState=it[id] ?: CustomerVoiceUi.ActionState(); snapshot?.let(::render) }
            } }
        }
        startTimer()
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); observe() }
    override fun onDetachedFromWindow() {
        subscription?.cancel(); subscription=null
        handler.removeCallbacks(tick); routeDialog?.dismiss(); routeDialog=null
        cancelKeypadReveal(); super.onDetachedFromWindow()
    }
    private fun startTimer() {
        handler.removeCallbacks(tick)
        if(isAttachedToWindow && callId!=null) handler.postDelayed(tick,1000)
    }
    private fun answerCall() {
        if(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            pendingAnswer=callId
            val request=requestMicrophone
            if(request!=null) request() else { error.text="Vui lòng cấp quyền micro từ ứng dụng."; error.visibility=VISIBLE }
        } else perform { CustomerVoice.answer(it) }
    }
    internal fun answerAfterPermission() {
        val id=pendingAnswer; pendingAnswer=null
        if(id!=null && id==callId && snapshot?.canRing(CustomerVoice.currentTime())==true) perform { CustomerVoice.answer(it) }
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Keep control spacing comfortable on tablets while the background fills its host.
        val contentWidth = minOf(MeasureSpec.getSize(widthMeasureSpec), dp(480))
        body.layoutParams.width = contentWidth
        terminal.layoutParams.width = contentWidth
        val height = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED)
            MeasureSpec.makeMeasureSpec(dp(680), MeasureSpec.EXACTLY) else heightMeasureSpec
        super.onMeasure(widthMeasureSpec, height)
    }

    internal fun render(value: CallSnapshot) {
        snapshot = value
        val model = CallPresentation(value, CustomerVoice.currentTime(), connection)
        direction.text = if (value.direction == "INBOUND") "↙  CUỘC GỌI ĐẾN" else "↗  CUỘC GỌI ĐI"
        title.text = CustomerVoiceUi.supportName
        number.text = value.businessNumber
        number.visibility = if(value.businessNumber.isNullOrBlank()) GONE else VISIBLE
        status.text = model.status; updateDuration()
        reason.visibility = GONE
        controls.visibility = if(model.showControls) VISIBLE else GONE
        if (!model.canControl) keypadOpen = false
        keypad.visibility = if (keypadOpen && model.canControl) VISIBLE else GONE
        val muted=audio.muted
        mute.update(if(muted) "Bật mic" else "Tắt mic",if(muted) "muted" else "mic",muted,model.canControl && !busy)
        keys.update("Bàn phím", "keypad", keypadOpen, model.canControl && !busy)
        route.isEnabled = model.canControl && !busy; route.alpha = if (route.isEnabled) 1f else 0.4f
        keypad.childrenEnabled(!busy)
        terminal.visibility = if (model.canEnd) VISIBLE else GONE
        end.update(if (model.incoming) "Từ chối" else "Kết thúc", "end", false, !busy)
        answer.visibility = if (model.incoming) VISIBLE else GONE
        answer.isEnabled = !busy; answer.alpha = if (busy) 0.4f else 1f
        progress.visibility = if (busy && !model.ended) VISIBLE else GONE
        if (model.ended) { routes = emptyList(); routeDialog?.dismiss(); handler.removeCallbacks(tick); onCallEnded?.invoke() }
        error.text=actionState.error
        error.visibility=if(actionState.error!=null) VISIBLE else GONE
        if(!model.canControl) { routeDialog?.dismiss(); routeDialog=null }
        updateRoute()
    }
    private fun cancelKeypadReveal() {
        keypadReveal?.let { if (keypad.viewTreeObserver.isAlive) keypad.viewTreeObserver.removeOnGlobalLayoutListener(it) }
        keypadReveal = null
    }
    private fun revealKeypadAfterLayout() {
        cancelKeypadReveal()
        if (!keypadOpen) return
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            cancelKeypadReveal()
            if (keypadOpen) scroll.smoothScrollTo(0, (keypad.bottom + body.paddingBottom - scroll.height).coerceAtLeast(0))
        }
        keypadReveal = listener
        keypad.viewTreeObserver.addOnGlobalLayoutListener(listener)
        keypad.requestLayout()
    }
    private fun updateDuration() {
        val text = callId?.let { CustomerVoiceUi.timings.duration(it,SystemClock.elapsedRealtime()) }
        duration.text = text; duration.visibility = if (text == null) GONE else VISIBLE
        duration.contentDescription = text?.let { "Thời lượng cuộc gọi $it" }
    }
    internal fun renderAudio(value: CallAudioState) {
        audio=value; routes=value.routes; snapshot?.let(::render)
    }
    private fun routeName(route: AudioRoute)=when(route.type) {
        CallEndpointCompat.TYPE_EARPIECE -> "Loa trong"
        CallEndpointCompat.TYPE_SPEAKER -> "Loa ngoài"
        CallEndpointCompat.TYPE_BLUETOOTH -> "Tai nghe Bluetooth"
        CallEndpointCompat.TYPE_WIRED_HEADSET -> "Tai nghe có dây"
        else -> route.name
    }
    private fun updateRoute() {
        val selected = routes.firstOrNull { it.selected }
        val name = selected?.let(::routeName) ?: "Âm thanh"
        // IDs affect only the icon; routing always sends the SDK-provided ID unchanged.
        val glyph = when (selected?.type) {
            CallEndpointCompat.TYPE_EARPIECE -> "receiver"
            CallEndpointCompat.TYPE_SPEAKER -> "speaker"
            else -> "headset"
        }
        route.update(name, glyph, false, snapshot?.let { CallPresentation(it,CustomerVoice.currentTime(),connection).canControl }==true && !busy)
        route.contentDescription = "Chọn tai nghe hoặc loa. $name"
    }
    private fun isBound(id: String, generation: Long) = callId==id && bindingGeneration==generation
    private fun showRoutes() {
        val id=callId ?: return
        if(snapshot?.let { CallPresentation(it,CustomerVoice.currentTime(),connection).canControl }!=true || busy) return
        val generation=bindingGeneration
        val available=CustomerVoice.audioStates.value[id]?.routes.orEmpty()
        if(available.isEmpty()) { error.text="Chưa có thiết bị âm thanh khả dụng"; error.visibility=VISIBLE; return }
        routeDialog?.dismiss()
        routeDialog=AlertDialog.Builder(context).setTitle("Chọn đường âm thanh")
            .setSingleChoiceItems(available.map(::routeName).toTypedArray(),available.indexOfFirst { it.selected }) { dialog,which ->
                if(isBound(id,generation)) perform { CustomerVoice.selectAudioRoute(it,available[which]) }
                dialog.dismiss()
            }.setNegativeButton("Đóng",null).show()
    }
    private fun perform(action: suspend (String)->Unit) {
        val id=callId ?: return
        val current=snapshot ?: return
        if(CallPresentation(current,CustomerVoice.currentTime()).ended || busy) return
        // App-owned actions reach their ACK/timeout even if this view detaches.
        CustomerVoiceUi.perform(id) { action(id) }
    }
    private inner class Control(text: String, glyph: String, val tint: Int, val terminal: Boolean, action: () -> Unit) : LinearLayout(context) {
        val icon = CallGlyph(context, glyph, if (terminal) Color.WHITE else accent)
        val caption = label(13, ink, bold = true)
        init {
            orientation = VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8))
            isClickable = true; isFocusable = true; importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
            descendantFocusability = FOCUS_BLOCK_DESCENDANTS
            icon.background = ripple(if (terminal) tint else Color.WHITE, 40)
            icon.isDuplicateParentStateEnabled = true
            caption.importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
            addView(icon, LayoutParams(dp(if (terminal) 76 else 66), dp(if (terminal) 76 else 66)))
            addView(caption, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(9) })
            setOnClickListener { action() }; update(text, glyph, false, true)
        }
        fun update(text: String, glyph: String, selected: Boolean, enabled: Boolean) {
            caption.text = text; icon.glyph = glyph; icon.color = if (terminal || selected) Color.WHITE else accent
            icon.background = ripple(if (terminal) tint else if (selected) accent else Color.WHITE, 40)
            icon.invalidate(); isSelected = selected; isEnabled = enabled; alpha = if (enabled) 1f else 0.4f
            contentDescription = text + if (!terminal && glyph in listOf("mic", "muted", "pause", "play", "keypad"))
                if (selected) ". Đang bật" else ". Đang tắt" else ""
        }
        override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(info); info.className = Button::class.java.name
        }
    }
    private fun control(text: String, glyph: String, tint: Int = accent, terminal: Boolean = false, action: () -> Unit) = Control(text, glyph, tint, terminal, action)
    private fun label(size: Int, color: Int, bold: Boolean = false) = TextView(context).apply {
        textSize = size.toFloat(); setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private fun shape(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun ripple(color: Int, radius: Int) = RippleDrawable(ColorStateList.valueOf(Color.argb(45, 8, 126, 117)), shape(color, radius), null)
    private fun spaced(top: Int, bottom: Int) = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
    private fun row(vararg views: View) = LinearLayout(context).apply {
        orientation = HORIZONTAL; gravity = Gravity.CENTER
        views.forEach { addView(it, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(5), dp(4), dp(5), dp(4)) }) }
    }
    private fun LinearLayout.childrenEnabled(enabled: Boolean) {
        for (index in 0 until childCount) {
            val child = getChildAt(index)
            if (child is LinearLayout) child.childrenEnabled(enabled) else child.isEnabled = enabled
        }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
