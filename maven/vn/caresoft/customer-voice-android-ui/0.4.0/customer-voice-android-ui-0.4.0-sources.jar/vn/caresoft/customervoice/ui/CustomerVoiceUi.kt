package vn.caresoft.customervoice.ui

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import vn.caresoft.customervoice.*

/** Optional, process-owned UI. Initialize once from Application.onCreate. */
object CustomerVoiceUi {
 internal val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
 internal val timings=CallTimings()
 internal var supportName="Chăm sóc khách hàng"; private set
 internal data class ActionState(val busy: Boolean=false, val error: String?=null)
 private val _actions=MutableStateFlow<Map<String,ActionState>>(emptyMap())
 internal val actions=_actions.asStateFlow()
 private val gate=PresentationGate()
 private var installed=false
 private var started=0
 fun install(application: Application, supportName: String="Chăm sóc khách hàng") {
  check(android.os.Looper.myLooper()==android.os.Looper.getMainLooper())
  this.supportName=supportName
  if(installed) return
  installed=true
  fun present() { gate.next(CustomerVoice.calls.value,started>0,CustomerVoice.currentTime())?.let { showCall(application,it) } }
  application.registerActivityLifecycleCallbacks(object: Application.ActivityLifecycleCallbacks {
   override fun onActivityStarted(activity: Activity) { started++; present() }
   override fun onActivityStopped(activity: Activity) { started=(started-1).coerceAtLeast(0) }
   override fun onActivityCreated(a: Activity,b: Bundle?) {}
   override fun onActivityResumed(a: Activity) {}
   override fun onActivityPaused(a: Activity) {}
   override fun onActivitySaveInstanceState(a: Activity,b: Bundle) {}
   override fun onActivityDestroyed(a: Activity) {}
  })
  scope.launch { CustomerVoice.calls.collect { calls ->
   calls.forEach { timings.observe(it,SystemClock.elapsedRealtime()) }
   val ids=calls.map { it.callId }.toSet()
   _actions.value=_actions.value.filterKeys { it in ids }
   present()
  } }
 }
 /** Android14+ special access for incoming call screens. Notification receipt is separate. */
 fun canShowIncomingScreen(context: Context): Boolean = android.os.Build.VERSION.SDK_INT<34 ||
  context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
 fun requestIncomingScreenPermission(activity: Activity) {
  if(android.os.Build.VERSION.SDK_INT>=34 && !canShowIncomingScreen(activity)) {
   val uri=android.net.Uri.parse("package:"+activity.packageName)
   activity.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,uri))
  }
 }
 fun incomingIntent(context: Context): PendingIntent = PendingIntent.getActivity(context,301,
  Intent(context,CustomerVoiceCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
  PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
 fun showCall(context: Context, callId: String) {
  gate.mark(callId)
  context.startActivity(Intent(context,CustomerVoiceCallActivity::class.java).putExtra("call_id",callId)
   .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP))
 }
 internal fun perform(id: String, action: suspend ()->Unit) {
  if(_actions.value[id]?.busy==true) return
  _actions.value=_actions.value+(id to ActionState(true))
  scope.launch {
   var error: String?=null
   try { action() } catch(e: CancellationException) { throw e }
   catch(e: Exception) { error=message(e) }
   finally { if(CustomerVoice.calls.value.any { it.callId==id }) _actions.value=_actions.value+(id to ActionState(error=error)) }
  }
 }
 fun message(error: Exception): String=when((error as? VoiceException)?.code) {
  "MICROPHONE_PERMISSION_REQUIRED" -> "Vui lòng cấp quyền micro để đàm thoại."
  "LOGIN_REQUIRED", "SESSION_REVOKED", "APP_DISABLED", "SESSION_CHANGED" -> "Vui lòng đăng nhập lại từ ứng dụng."
  "CALL_NOT_RINGING", "ANSWERED_ELSEWHERE", "CALL_ENDED_LOCALLY" -> "Cuộc gọi đã kết thúc hoặc được trả lời trên thiết bị khác."
  "NETWORK_RECOVERY_TIMEOUT" -> "Cuộc gọi đã kết thúc vì mất kết nối quá lâu. Vui lòng kiểm tra mạng rồi gọi lại."
  "MEDIA_RECONNECTING" -> "Đang kết nối lại cuộc gọi…"
  "ROUTE_CHANGE_TIMEOUT" -> "Chưa chuyển được âm thanh. Vui lòng kiểm tra lại thiết bị."
  else -> "Chưa thể thực hiện thao tác. Vui lòng kiểm tra kết nối và thử lại."
 }
}
