package vn.caresoft.customervoice.ui

import java.time.Instant
import java.util.Locale
import vn.caresoft.customervoice.CallSnapshot
import vn.caresoft.customervoice.CallConnectionState

internal class CallPresentation(val snapshot: CallSnapshot, now: Instant, connection: CallConnectionState?=null) {
 val incoming=snapshot.canRing(now)
 val ended=snapshot.terminal || snapshot.lost ||
     (snapshot.direction=="INBOUND" && snapshot.state=="RINGING" && !incoming)
 private val controlsOwner=snapshot.isOwner || snapshot.deviceStatus=="winner"
 val showControls=!ended && snapshot.state=="ACTIVE" && controlsOwner
 val canControl=showControls && connection!=CallConnectionState.RECONNECTING
 val canEnd=!ended && (snapshot.direction=="OUTBOUND" || incoming || controlsOwner)
 val status=when {
  snapshot.lost -> "Đã xử lý trên thiết bị khác"
  ended -> "Cuộc gọi đã kết thúc"
  connection==CallConnectionState.RECONNECTING -> "Đang kết nối lại…"
  incoming -> "Cuộc gọi đến"
  snapshot.state=="ACTIVE" -> "Đang đàm thoại"
  snapshot.state=="CONNECTING" -> "Đang kết nối…"
  snapshot.state=="RINGING" -> "Đang đổ chuông…"
  else -> "Đang gọi…"
 }
}

/** Process-owned timing survives screen recreation; starts when ACTIVE is first observed. */
internal class CallTimings {
 private data class Time(val start: Long, var end: Long?=null)
 private val times=linkedMapOf<String,Time>()
 fun observe(call: CallSnapshot, now: Long) {
  if(call.state=="ACTIVE" && !call.lost) times.getOrPut(call.callId) { Time(now) }
  if(call.terminal || call.lost) times[call.callId]?.let { if(it.end==null) it.end=now }
  while(times.size>128) times.remove(times.keys.first())
 }
 fun duration(id: String, now: Long): String? = times[id]?.let {
  val seconds=((it.end ?: now)-it.start).coerceAtLeast(0)/1000
  String.format(Locale.ROOT,"%02d:%02d",seconds/60,seconds%60)
 }
}
internal class PresentationGate {
 private val shown=linkedSetOf<String>()
 fun mark(id: String) { shown.add(id); while(shown.size>128) shown.remove(shown.first()) }
 fun next(calls: List<CallSnapshot>, foreground: Boolean, now: Instant): String? {
  if(!foreground) return null
  val call=calls.lastOrNull { !it.terminal && !CallPresentation(it,now).ended && it.callId !in shown } ?: return null
  mark(call.callId); return call.callId
 }
}
