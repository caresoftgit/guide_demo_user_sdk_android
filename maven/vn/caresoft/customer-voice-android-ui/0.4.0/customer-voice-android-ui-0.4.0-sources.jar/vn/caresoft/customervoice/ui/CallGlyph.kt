package vn.caresoft.customervoice.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Small vector glyphs keep the optional UI free of image and icon dependencies. */
@SuppressLint("ViewConstructor")
internal class CallGlyph(context: Context, var glyph: String, var color: Int) : View(context) {
    private val path = Path()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    init { importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = minOf(width, height) * 0.43f
        canvas.save()
        canvas.translate((width - size) / 2, (height - size) / 2)
        canvas.scale(size / 24, size / 24)
        pen.color = color
        pen.style = Paint.Style.STROKE
        fun line(x: Float, y: Float, xx: Float, yy: Float) = canvas.drawLine(x, y, xx, yy, pen)
        when (glyph) {
            "person" -> {
                canvas.drawCircle(12f, 7f, 4f, pen)
                canvas.drawArc(3f, 13f, 21f, 29f, 180f, 180f, false, pen)
            }
            "mic", "muted" -> {
                canvas.drawRoundRect(9f, 2f, 15f, 14f, 3f, 3f, pen)
                canvas.drawArc(5f, 6f, 19f, 19f, 0f, 180f, false, pen)
                line(12f, 19f, 12f, 22f); line(8f, 22f, 16f, 22f)
                if (glyph == "muted") line(2f, 2f, 22f, 22f)
            }
            "pause" -> { line(8f, 4f, 8f, 20f); line(16f, 4f, 16f, 20f) }
            "play" -> {
                path.reset()
                path.apply { moveTo(7f, 3f); lineTo(20f, 12f); lineTo(7f, 21f); close() }
                pen.style = Paint.Style.FILL; canvas.drawPath(path, pen)
            }
            "keypad" -> {
                pen.style = Paint.Style.FILL
                for (x in listOf(5f, 12f, 19f)) for (y in listOf(4f, 11f, 18f)) canvas.drawCircle(x, y, 1.8f, pen)
            }
            "speaker" -> {
                path.reset()
                path.apply { moveTo(3f, 9f); lineTo(7f, 9f); lineTo(12f, 4f); lineTo(12f, 20f); lineTo(7f, 15f); lineTo(3f, 15f); close() }
                canvas.drawPath(path, pen)
                canvas.drawArc(9f, 5f, 21f, 19f, -55f, 110f, false, pen)
                canvas.drawArc(12f, 1f, 26f, 23f, -55f, 110f, false, pen)
            }
            "headset" -> {
                canvas.drawArc(3f, 3f, 21f, 23f, 180f, 180f, false, pen)
                canvas.drawRoundRect(3f, 11f, 7f, 21f, 2f, 2f, pen)
                canvas.drawRoundRect(17f, 11f, 21f, 21f, 2f, 2f, pen)
            }
            "receiver" -> {
                canvas.drawRoundRect(6f, 1f, 18f, 23f, 3f, 3f, pen)
                line(10f, 19f, 14f, 19f)
            }
            "phone", "end" -> {
                canvas.save()
                if (glyph == "end") canvas.rotate(135f, 12f, 12f)
                path.reset()
                path.apply {
                    moveTo(5f, 2f); lineTo(9f, 2f); lineTo(11f, 7f); lineTo(8f, 10f)
                    quadTo(10f, 14f, 14f, 16f); lineTo(17f, 13f); lineTo(22f, 15f)
                    lineTo(22f, 19f); quadTo(22f, 23f, 17f, 21f)
                    quadTo(4f, 17f, 2f, 6f); quadTo(1f, 2f, 5f, 2f); close()
                }
                pen.style = Paint.Style.FILL; canvas.drawPath(path, pen)
                canvas.restore()
            }
        }
        canvas.restore()
    }
}
