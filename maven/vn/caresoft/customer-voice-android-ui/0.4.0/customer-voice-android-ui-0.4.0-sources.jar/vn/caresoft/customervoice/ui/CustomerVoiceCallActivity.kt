package vn.caresoft.customervoice.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import vn.caresoft.customervoice.CustomerVoice

/** Supplied call screen. Leaving the Activity never changes the call. */
class CustomerVoiceCallActivity : Activity() {
 private lateinit var view: CustomerVoiceCallView
 override fun onCreate(state: Bundle?) {
  super.onCreate(state)
  if(android.os.Build.VERSION.SDK_INT>=27) { setShowWhenLocked(true); setTurnScreenOn(true) }
  view=CustomerVoiceCallView(this)
  view.onCallEnded={ if(!isFinishing) finish() }
  view.requestMicrophone={ requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),71) }
  view.setOnApplyWindowInsetsListener { v,insets ->
   v.setPadding(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom); insets
  }
  setContentView(view); bindIntent()
 }
 override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); bindIntent() }
 private fun bindIntent() {
  val id=intent.getStringExtra("call_id") ?: CustomerVoice.calls.value.lastOrNull { CustomerVoice.isCallPresentable(it.callId) }?.callId
  if(id!=null && CustomerVoice.isCallPresentable(id)) view.bind(id) else finish()
 }
 override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, grants: IntArray) {
  super.onRequestPermissionsResult(code,permissions,grants)
  if(code==71 && grants.firstOrNull()==PackageManager.PERMISSION_GRANTED) view.answerAfterPermission()
 }
 override fun onDestroy() { view.unbind(); super.onDestroy() }
}
